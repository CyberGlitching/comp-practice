# GDDC FA26 Game-Day Checklist — Real Underground Media — print & tape to desk

**Team # ___   (all IPs = 172.16.[#].x)   ·   Scoreboard: rumscoring.uacyber.org · CTF: rumctf.uacyber.org · Discord: get SSO pw there**

**Roles:** Captain/Win-DC ___  Linux(web+file) ___  Linux(msgboard)+pfSense ___  Jumpbox-driver(deploy.sh) ___  Injects/CTF ___

---

## ☐ T-0 · First 5 min — DON'T harden yet
- ☐ Open **scoreboard** + **Discord** (SSO password posts here) + **notes doc** (timestamp every action)
- ☐ Join Discord: discord.gg/NQ4S47aSQH · bring physical student ID
- ☐ On the Kali jumpbox: `cd kit/lab/jumpbox && ./deploy.sh inventory` (enter team #) → `./deploy.sh status`

## ☐ Minutes 5–20 · Lockdown — drive it from the jumpbox
```
./deploy.sh push       # kit to every box
./deploy.sh triage     # read-only hunt+agent-audit on all -> reports/  (read the [!] lines)
./deploy.sh rotate     # root/Administrator off the default (NOT scored users)
./deploy.sh harden     # STAGGERED - one box at a time, watch the board between each
```
Or per box: `./deploy.sh harden web` / `… dc`. pfSense harden is GUI (deploy prints the steps).

**☐ Change ALL default passwords first — Red team has this packet. Everything is `bb123#123`:**

| pfSense | admin / bb123#123 | Windows | Administrator / bb123#123 |
|---|---|---|---|
| Linux (all 3) | root / bb123#123 | Kali | kali / kali |
| SSO | teamX / (Discord) | **try `bb123#123` first for anything** | |

## ☐ Minutes 20–45 · Evict & verify
- ☐ Work every `[!]` in `reports/*-hunt.txt` — **kill the loop (cron/task/timer) before the symptom**
- ☐ **Any AI agent = red-team persistence this year (rule 10). Kill on sight** — `agent-hunt.sh` (no agent is scored).
- ☐ Watch scoreboard after each box; a service you just hardened goes red → undo your last change
- ☐ `./deploy.sh sweep 5` running in a pane = re-triage every 5 min, alerts on re-compromise

## ☐ All day · Steady state
- ☐ **Injects** (35%, **8 total**): owner writes w/ template, defenders feed findings — don't stop defense
- ☐ **CTF** (20%, 9–4, flag `rum{...}`): floater only, when defense is calm
- ☐ Gold Team prep from notes (impact→cause→action→risk; **scope before obligations**)

---

## Scored services — don't firewall off / don't break  (checks every 60s)
| Router (pfSense .1) | ICMP, DNS | Web (Ubuntu .10) | ICMP, SSH, HTTP |
|---|---|---|---|
| **File (Ubuntu .20)** | ICMP, SSH, FTP(passive!), **SMB** | **MsgBoard (Canaima .30)** | ICMP, SSH, Message Board |
| **Windows DC (.40)** | ICMP, **SSH(OpenSSH!)**, DNS, CA | | |

**Easy-to-miss this year:** DC is scored on **SSH** (install/run OpenSSH Server — `Harden.ps1 -Role DC` step 6b) · **SMB** on File (keep `smbd` up) · DNS on BOTH router and DC · keep ICMP everywhere · FTP passive ports 40000-40100.

## When two things are on fire — priority order
**1.** Scored service RED → fix now  **2.** Active intrusion → evict + kill persistence  **3.** Inject due → owner writes  **4.** Finish hardening  **5.** CTF (spare hands only)

## Top ways teams bleed points (don't)
1. **Self-inflicted downtime** — firewalling a scored port, changing a service pw w/o its config, over-locking SSH → that's why `harden` is **staggered**, board-in-view
2. **Injects slow/thin** — assign an owner, answer all 8
3. **Unseen re-compromise** — `deploy.sh sweep` + one person owning the board

## Rules (penalties / DQ)
- **NO reverting/creating VM snapshots or templates → significant penalty**  · **NO autonomous AI agents (rule 10)**
- NO touching other teams / outside recon → **DQ** · offensive tools (nmap) on YOUR network only
- NO changing IP/VLAN scheme unless an inject says so · traffic generators inject fake "malicious" traffic from random IPs — **don't chase every weird IP**
- Out of scope (don't lock down): Black Team FW, Proxmox portal, CTFd, Authentik SSO, Kali jumpboxes

Actions log on each box → `/root/.blue/actions.log` + `C:\ProgramData\blue\actions.log` = your inject/Gold-Team evidence.
