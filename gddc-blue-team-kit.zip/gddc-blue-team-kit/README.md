# GDDC Blue Team Kit

A two-week training camp and competition toolkit for the **Great Dane Defense Competition**
(Red vs. Blue, UAlbany Cyber Defense Organization). Built from the Spring '26 Blue Team packet:
a 7-system network on Proxmox — pfSense, two Rocky 9 boxes, two Ubuntu 24.04 boxes, two Server 2016
DCs — scored on service uptime (35%), injects (35%), CTF (20%), and a Gold Team interview (10%).

Everything here is **defensive**: triage, hardening, monitoring, and a safe practice lab that
plants *inert decoys* of last year's mess so you can rehearse the cleanup against a clock.

> **Rules check (from the packet).** Scripting is allowed as long as every tool is coded on the
> spot or publicly available; AI *agents* (Claude Code, OpenClaw, Aider, etc.) are banned during
> play, and paid AI "agents such as Claude" are allowed only in non-autonomous use. These scripts
> are plain Bash/PowerShell/Python you run yourself — no agent, no network calls to an LLM — so they
> sit on the right side of that line. Host them wherever you like (a repo of yours is fine; it only
> has to be publicly reachable). Read [`docs/RULES.md`](docs/RULES.md) before you lean on any of it.

## What's in the box

```
linux/      Bash: triage, harden, monitor, backup, app + agent audits (Rocky 9 / Ubuntu 24.04)
windows/    PowerShell: triage, harden, AD + ADCS audit, persistence cleanup, monitor (Server 2016)
pfsense/    Read-only audit for the firewall (DNS + ICMP are scored on it)
lab/        Practice harness: chaos planters (INERT), a grader, and scorebot (a DSSS-style scoreboard)
lab/build/  Range builder: stands up the whole packet topology on nested Proxmox (see its README)
docs/       The training camp: 14-day plan, playbooks, inject drills, Gold Team prep, scoring math
```

## Building the range (nested Proxmox on your main PC)

`lab/build/` automates the whole topology — isolated bridge, the four Linux boxes + ops via
cloud-init (services + scored users install themselves), and VM creation + post-install scripts for
pfSense and the two DCs. Run Proxmox nested inside VMware Workstation (give it ≥44GB RAM, enable
VT-x/EPT), then on the Proxmox host: edit `lab/build/config.env`, and run `01-network.sh` →
`02-images.sh` → `03-pfsense.sh` → `04-linux.sh` → `05-windows.sh`. Full walkthrough and timing in
[`lab/build/README.md`](lab/build/README.md). The build's IPs match `scorebot`'s `services.yml` out
of the box.

## Fast start (practice lab)

On your Proxmox lab, not the real competition network:

```bash
# 1. On a throwaway practice VM (Rocky or Ubuntu):
sudo touch /etc/dog-lab                      # opt-in marker
# 2. Snapshot the VM in Proxmox (your lab = snapshots allowed).
# 3. Plant last year's mess (inert decoys + real misconfigs):
sudo ./lab/chaos-linux.sh plant --i-know-this-is-a-lab --service sshd --n 12
# 4. In another terminal on your workstation, watch the board:
python3 lab/scorebot.py --config services.yml --interval 30   # edit services.yml for your IPs
# 5. Clean the box with the real tools, racing the clock:
sudo ./linux/hunt.sh                         # see what's wrong
sudo ./linux/harden.sh web                   # fix it (role: web|file|msgboard|generic)
sudo ./linux/agent-hunt.sh                   # kill any AI agent (none is scored in FA26)
sudo ./linux/watch.sh                        # leave running; alerts on re-compromise
# 6. Grade yourself, then reset the snapshot and go again, faster:
sudo ./lab/chaos-linux.sh grade --hints
```

Windows is the same shape: `New-Item C:\dog-lab -ItemType File`, snapshot, then
`lab\Chaos-Windows.ps1 -Mode plant -IKnowThisIsALab`, clean with `windows\Hunt.ps1` /
`windows\Harden.ps1 -Role DC`, grade with `-Mode grade`.

## Competition day (FA26 — Real Underground Media)

Tuned to the Nov 21 2026 packet: 5 scored systems on `172.16.X.0/24` — Router/pfSense `.1`
(ICMP, DNS), Web/Ubuntu `.10` (ICMP, SSH, HTTP), File/Ubuntu `.20` (ICMP, SSH, FTP, SMB),
Message Board/Canaima `.30` (ICMP, SSH, board), Windows DC `.40` (ICMP, **SSH**, DNS, CA).
Print [`docs/CHECKLIST.md`](docs/CHECKLIST.md) (one page) and drive the day from the Kali jumpbox:

```bash
cd lab/jumpbox
./deploy.sh inventory     # enter team # -> derives all IPs
./deploy.sh status        # quick up/down of every scored service
./deploy.sh push          # kit to every box over SSH
./deploy.sh triage        # read-only hunt+agent-audit on all -> reports/  (SAFE)
./deploy.sh rotate        # root/Administrator off the default bb123#123  (SAFE)
./deploy.sh harden        # STAGGERED, one box at a time, scoreboard pause between each
./deploy.sh sweep 5       # leave running: re-triage every 5 min, alerts on re-compromise
```

Full jumpbox docs: [`lab/jumpbox/README.md`](lab/jumpbox/README.md). The per-box scripts still work
standalone (`./linux/harden.sh web|file|msgboard`, `./windows/Harden.ps1 -Role DC`) if you prefer to
log into a box directly.

**Easy-to-miss this year:** the DC is scored on **SSH** (run OpenSSH Server — `Harden.ps1 -Role DC`
step 6b), **SMB** is scored on the File server (keep `smbd` up), and **no AI agent is scored** — rule
10 bans them, so any agent you find is red-team persistence: kill it (`agent-hunt.sh`).

## The golden rule of this competition

**Uptime + injects are 70% of the score; the CTF is 20%.** A locked-down box that fails its scoring
check is worth less than a slightly-messy box that stays green. That's why `deploy.sh harden` is
**staggered** — one box, then watch the board — and every per-box script warns before it can drop a
scored service. Read [`docs/SCORING-STRATEGY.md`](docs/SCORING-STRATEGY.md) for the point math.

## Update the lists for the new packet

If you get a Spring-27 packet, the scored users, services, and IPs may change. Update:
- `linux/common.sh` → `SCORED_USERS`, `ROLE_PORTS`, `ROLE_SERVICES`
- `windows/common.ps1` → `$ScoredUsers`, `$KeepUsers`, `$PrivAllow`
- `lab/scorebot.py` → `services.yml` (IPs + checks)

Send me the new packet and I'll retune all of it.

## Safety

The lab planters install **inert decoys** — no reverse shells, no real ransomware (files are backed
up then reversibly renamed), no working webshells or auth bypasses. They refuse to run without a
`dog-lab` marker file, and each has a `restore` mode. Run them only on throwaway lab VMs you own.
See [`docs/RULES.md`](docs/RULES.md).
