#!/usr/bin/env python3
"""
jumpbox-web.py - local web dashboard for the GDDC FA26 jumpbox. Stdlib only.

  python3 jumpbox-web.py [--team N] [--port 8000]
  then open http://127.0.0.1:8000 ON THE JUMPBOX

Binds to 127.0.0.1 ONLY - this panel can SSH-as-root to every box, so it must never be reachable by
other teams / red team. To view from another of YOUR machines:  ssh -L 8000:127.0.0.1:8000 kali@<jumpbox>

Features:
  * Live red/green status board of every scored service (auto-refresh).
  * One-click SAFE actions: push / triage / rotate / sweep -> runs ./deploy.sh, output streamed.
  * Per-box HARDEN button -> opens the REAL interactive harden session in an embedded terminal (ttyd),
    so every per-step prompt is preserved. One box per button = staggered by design; watch the board
    between boxes. (Needs 'ttyd': sudo apt install ttyd. Without it, the button shows the command.)
  * Reports viewer with [!] findings highlighted.
Heavy work is delegated to ./deploy.sh so there's one source of truth for the SSH actions.
"""
import argparse, json, os, re, shutil, socket, struct, subprocess, threading, time, html
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
DEPLOY = os.path.join(HERE, 'deploy.sh')
ENVF = os.path.join(HERE, '.jump.env')
SCOREBOARD = 'https://rumscoring.uacyber.org'

# Inventory - keep in sync with deploy.sh (both hardcoded to the FA26 packet).
INVENTORY = [
    ('router',   1,  'pfSense 2.9',  [('ICMP','icmp',None),('DNS','dns','rumscoring.uacyber.org')]),
    ('web',      10, 'Ubuntu 26.04', [('ICMP','icmp',None),('SSH','tcp',22),('HTTP','tcp',80)]),
    ('file',     20, 'Ubuntu 26.04', [('ICMP','icmp',None),('SSH','tcp',22),('FTP','tcp',21),('SMB','tcp',445)]),
    ('msgboard', 30, 'Canaima 9.0',  [('ICMP','icmp',None),('SSH','tcp',22),('Board','tcp',80)]),
    ('dc',       40, 'Server 2016',  [('ICMP','icmp',None),('SSH','tcp',22),('DNS','dns','dog.local'),('CA','tcp',135)]),
]
# role -> the deploy.sh harden argument
HARDEN_ARG = {'web':'web','file':'file','msgboard':'msgboard','dc':'dc','router':'router'}

STATE = {'team': None, 'status': {}, 'log': '', 'running': None}
TTYD = {}   # role -> (port, proc)
LOCK = threading.Lock()

def load_team():
    if os.path.exists(ENVF):
        for line in open(ENVF):
            m = re.match(r'TEAM=(\d+)', line.strip())
            if m: return int(m.group(1))
    return None

def ip_of(suffix): return f"172.16.{STATE['team']}.{suffix}"

# ---- probes ----
def p_icmp(ip):
    try: return subprocess.run(['ping','-c','1','-W','2',ip],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5).returncode==0
    except Exception: return False
def p_tcp(ip,port):
    try:
        with socket.create_connection((ip,port),timeout=3): return True
    except Exception: return False
def p_dns(ip,qname):
    try:
        tid=os.getpid()&0xFFFF
        q=b''.join(bytes([len(p)])+p.encode() for p in qname.split('.'))+b'\x00'
        pkt=struct.pack('>HHHHHH',tid,0x0100,1,0,0,0)+q+struct.pack('>HH',1,1)
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as u:
            u.settimeout(3); u.sendto(pkt,(ip,53)); data,_=u.recvfrom(512)
        return (data[3]&0x0F)==0 and struct.unpack('>H',data[6:8])[0]>=1
    except Exception: return False

def probe_all():
    if not STATE['team']: return
    res={}
    for role,suf,osname,checks in INVENTORY:
        ip=ip_of(suf); svc={}
        for label,kind,arg in checks:
            svc[label]= p_icmp(ip) if kind=='icmp' else p_tcp(ip,arg) if kind=='tcp' else p_dns(ip,arg) if kind=='dns' else False
        res[role]={'ip':ip,'os':osname,'svc':svc}
    with LOCK: STATE['status']=res

def status_loop():
    while True:
        try: probe_all()
        except Exception: pass
        time.sleep(10)

# ---- safe actions via deploy.sh ----
def run_action(args, env_extra=None):
    with LOCK:
        if STATE['running']: return False
        STATE['running']=args[0]; STATE['log']=f"$ ./deploy.sh {' '.join(args)}\n"
    def worker():
        env=dict(os.environ); env['TEAM']=str(STATE['team'])
        if env_extra: env.update(env_extra)
        try:
            p=subprocess.Popen(['bash',DEPLOY,*args],cwd=HERE,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            for line in p.stdout:
                with LOCK: STATE['log']+=re.sub(r'\x1b\[[0-9;]*m','',line)
            p.wait()
            with LOCK: STATE['log']+=f"\n[done: exit {p.returncode}]\n"
        except Exception as e:
            with LOCK: STATE['log']+=f"\n[error: {e}]\n"
        finally:
            with LOCK: STATE['running']=None
    threading.Thread(target=worker,daemon=True).start()
    return True

# ---- harden via embedded terminal (ttyd) ----
def free_port():
    s=socket.socket(); s.bind(('127.0.0.1',0)); p=s.getsockname()[1]; s.close(); return p

def launch_harden(role):
    arg=HARDEN_ARG.get(role)
    if not arg: return {'err':'unknown role'}
    if shutil.which('ttyd') is None:
        return {'need_ttyd':True,'cmd':f"cd {HERE} && TEAM={STATE['team']} ./deploy.sh harden {arg}"}
    # reuse a live session if present
    old=TTYD.get(role)
    if old and old[1].poll() is None:
        return {'port':old[0]}
    port=free_port()
    env=dict(os.environ); env['TEAM']=str(STATE['team'])
    # -W writable (prompts need input), -i bind localhost, -o exit after the session ends
    cmd=['ttyd','-p',str(port),'-i','127.0.0.1','-W','-o','-t','titleFixed=harden '+role,
         'bash','-lc',f"cd {HERE} && ./deploy.sh harden {arg}; echo; read -p 'done - close this tab'"]
    try:
        proc=subprocess.Popen(cmd,cwd=HERE,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    except Exception as e:
        return {'err':str(e)}
    TTYD[role]=(port,proc); time.sleep(0.6)
    return {'port':port}

def read_reports():
    d=os.path.join(HERE,'reports'); out=[]
    if os.path.isdir(d):
        for f in sorted(os.listdir(d)):
            if f.endswith('.txt'):
                try: out.append((f,open(os.path.join(d,f),errors='replace').read()))
                except Exception: pass
    return out

PAGE = r"""<!doctype html><html><head><meta charset=utf-8><title>GDDC FA26 Jumpbox</title>
<style>
 body{background:#0b0f14;color:#e6edf3;font:14px system-ui,sans-serif;margin:0;padding:16px}
 h1{font-size:17px;margin:0 0 2px} h3{font-size:14px;margin:12px 0 4px}
 .sub{color:#7d8590;font-size:12px;margin-bottom:10px}
 .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px;margin-bottom:12px}
 .card{background:#11161c;border:1px solid #1b222b;border-radius:8px;padding:10px}
 .card h4{margin:0 0 2px;font-size:14px} .card .ip{color:#7d8590;font-size:11px;margin-bottom:6px}
 .pill{display:inline-block;margin:2px 3px 0 0;padding:2px 8px;border-radius:10px;font-size:11px}
 .up{background:#12361f;color:#3fb950} .down{background:#3a1416;color:#f85149;font-weight:600}
 button{background:#1f6feb;color:#fff;border:0;border-radius:6px;padding:6px 11px;font-size:13px;cursor:pointer;margin:4px 6px 0 0}
 button.safe{background:#238636} button.hd{background:#9e6a03;padding:4px 9px;font-size:12px;margin-top:8px} button:disabled{opacity:.5;cursor:wait}
 input{background:#0d1117;border:1px solid #30363d;color:#e6edf3;border-radius:6px;padding:6px;font-size:13px}
 pre{background:#0d1117;border:1px solid #1b222b;border-radius:6px;padding:10px;max-height:280px;overflow:auto;font-size:12px;white-space:pre-wrap}
 .hl{color:#f85149} .cols{display:flex;gap:14px;flex-wrap:wrap} .col{flex:1;min-width:360px}
 .warn{background:#3a2a10;border:1px solid #5a4410;color:#e3b341;padding:8px;border-radius:6px;font-size:12px;margin-bottom:10px}
 #termwrap{display:none;margin:10px 0} iframe{width:100%;height:420px;border:1px solid #30363d;border-radius:6px;background:#000}
 code{background:#161b22;padding:1px 5px;border-radius:4px;font-size:12px}
</style></head><body>
<h1>GDDC FA26 Jumpbox — Real Underground Media</h1>
<div class=sub>team <b id=team>?</b> · board refreshes every 10s · official scoreboard: __SB__</div>
<div class=warn>Bound to 127.0.0.1 only. Don't expose this — it can SSH-as-root to every box. Harden one box, then watch the board before the next.</div>
<div class=grid id=grid>loading…</div>
<div>
  <button class=safe onclick="act('push')">Push kit</button>
  <button class=safe onclick="act('triage')">Triage (read-only)</button>
  <input id=np placeholder="new password" size=14>
  <button class=safe onclick="rotate()">Rotate root/Admin</button>
  <button onclick="act('sweep','5')" title="re-triage every 5 min">Start sweep</button>
  <button onclick="loadReports()">Refresh reports</button>
</div>
<div id=termwrap><h3 id=termtitle>Harden</h3><div id=termbody></div></div>
<div class=cols>
  <div class=col><h3>Action output</h3><pre id=log>—</pre></div>
  <div class=col><h3>Reports</h3><pre id=reports>run triage…</pre></div>
</div>
<script>
const SAFE=['ICMP','SSH','HTTP','FTP','SMB','DNS','CA','Board'];
async function refresh(){
  let d=await (await fetch('/api/status')).json();
  document.getElementById('team').textContent=d.team??'?';
  let g=document.getElementById('grid'); g.innerHTML='';
  for(const [role,info] of Object.entries(d.status||{})){
    let pills=Object.entries(info.svc).map(([k,v])=>`<span class="pill ${v?'up':'down'}">${k}</span>`).join('');
    let hb = role==='router'
      ? `<button class=hd onclick="hardenBox('router')">Harden (pfSense steps)</button>`
      : `<button class=hd onclick="hardenBox('${role}')">Harden ${role}</button>`;
    g.innerHTML+=`<div class=card><h4>${role}</h4><div class=ip>${info.ip} · ${info.os}</div>${pills}<br>${hb}</div>`;
  }
}
async function poll(){ let d=await (await fetch('/api/log')).json();
  document.getElementById('log').textContent=d.log||'—';
  for(const b of document.querySelectorAll('button.safe')) b.disabled=!!d.running; }
async function act(a,arg){ await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:a,arg:arg})}); poll(); }
async function rotate(){ let np=document.getElementById('np').value; if(!np){alert('type a new password');return;}
  await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'rotate',newpass:np})}); poll(); }
async function hardenBox(role){
  let d=await (await fetch('/api/harden',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({role})})).json();
  let w=document.getElementById('termwrap'), t=document.getElementById('termtitle'), b=document.getElementById('termbody');
  w.style.display='block'; t.scrollIntoView({behavior:'smooth'});
  if(d.port){ t.textContent='Harden '+role+' — approve each step here, then watch the scoreboard before the next box';
    b.innerHTML=`<iframe src="http://127.0.0.1:${d.port}/"></iframe>`; }
  else if(d.need_ttyd){ t.textContent='Harden '+role+' — ttyd not installed';
    b.innerHTML=`<pre>Install the in-browser terminal once:  <code>sudo apt install -y ttyd</code>\nThen click Harden again. For now, run this in a terminal:\n\n<code>${d.cmd}</code></pre>`; }
  else { b.innerHTML=`<pre>${d.err||'error'}</pre>`; }
}
async function loadReports(){ let d=await (await fetch('/api/reports')).json();
  document.getElementById('reports').innerHTML=d.html||'(none yet)'; }
refresh(); poll(); loadReports(); setInterval(refresh,10000); setInterval(poll,1500);
</script></body></html>"""

class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def _send(self,code,body,ctype='application/json'):
        b=body.encode() if isinstance(body,str) else body
        self.send_response(code); self.send_header('Content-Type',ctype); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path=='/' or self.path.startswith('/index'):
            self._send(200,PAGE.replace('__SB__',SCOREBOARD),'text/html; charset=utf-8')
        elif self.path=='/api/status':
            with LOCK: self._send(200,json.dumps({'team':STATE['team'],'status':STATE['status']}))
        elif self.path=='/api/log':
            with LOCK: self._send(200,json.dumps({'log':STATE['log'],'running':STATE['running']}))
        elif self.path=='/api/reports':
            parts=[]
            for name,txt in read_reports():
                esc=re.sub(r'(\[!\][^\n]*)',r'<span class=hl>\1</span>',html.escape(txt))
                parts.append(f"<b>{html.escape(name)}</b>\n{esc}")
            self._send(200,json.dumps({'html':"\n\n".join(parts)}))
        else: self._send(404,'{}')
    def do_POST(self):
        n=int(self.headers.get('Content-Length',0)); body=json.loads(self.rfile.read(n) or b'{}')
        if self.path=='/api/action':
            a=body.get('action')
            if a=='push': ok=run_action(['push'])
            elif a=='triage': ok=run_action(['triage'])
            elif a=='rotate':
                np=str(body.get('newpass',''))
                if not np or '"' in np or "'" in np: return self._send(400,json.dumps({'err':'bad password'}))
                ok=run_action(['rotate'],{'NEWPASS':np})
            elif a=='sweep': ok=run_action(['sweep',str(body.get('arg','5'))])
            else: return self._send(400,json.dumps({'err':'unknown action'}))
            return self._send(200,json.dumps({'started':bool(ok)}))
        if self.path=='/api/harden':
            return self._send(200,json.dumps(launch_harden(str(body.get('role','')))))
        self._send(404,'{}')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--team',type=int); ap.add_argument('--port',type=int,default=8000)
    a=ap.parse_args()
    STATE['team']=a.team or load_team()
    if not STATE['team']:
        print("No team number. Run ./deploy.sh inventory first, or pass --team N."); return
    threading.Thread(target=status_loop,daemon=True).start()
    print(f"Jumpbox dashboard: http://127.0.0.1:{a.port}  (team {STATE['team']})")
    print("Bound to localhost only. Harden opens an in-browser terminal (needs ttyd). Ctrl-C to stop.")
    ThreadingHTTPServer(('127.0.0.1',a.port),H).serve_forever()

if __name__=='__main__': main()
