#!/usr/bin/env bash
# deploy.sh - GDDC FA26 jumpbox orchestrator. Run from a Kali jumpbox to drive the whole kit across
# every scored box over SSH. Hardcoded to the Real Underground Media topology (Nov 21 2026).
#
# Topology (172.16.X.0/24, X = your team number):
#   router    .1   pfSense 2.9        scored: ICMP, DNS
#   web       .10  Ubuntu 26.04       scored: ICMP, SSH, HTTP
#   file      .20  Ubuntu 26.04       scored: ICMP, SSH, FTP, SMB
#   msgboard  .30  Canaima 9.0        scored: ICMP, SSH, Message Board
#   dc        .40  Server 2016        scored: ICMP, SSH, DNS, CA
#
# Phases (run in this order):
#   ./deploy.sh inventory        show the resolved IPs for your team number
#   ./deploy.sh status           quick up/down of every scored service (a mini scoreboard)
#   ./deploy.sh push             copy the kit to every box (safe)
#   ./deploy.sh triage           run read-only hunt/agent-audit on every box, pull reports here (safe)
#   ./deploy.sh rotate           change root/Administrator from the default to YOUR team password (safe)
#   ./deploy.sh harden [role]    STAGGERED hardening, one box at a time, scoreboard pause between each
#   ./deploy.sh sweep [minutes]  loop: re-triage every N min, alert on changes (leave running)
#
# Needs: sshpass, ssh, scp, nc, ping (all on Kali). Connection creds live in ./.jump.env (chmod 600).
set -uo pipefail
cd "$(dirname "$0")"
KIT="$(cd ../.. && pwd)"                       # repo root (this is lab/jumpbox/)
ENVF="./.jump.env"
SCOREBOARD="https://rumscoring.uacyber.org"

# ---- creds / team number persist in .jump.env ----
[[ -f "$ENVF" ]] && source "$ENVF"
TEAM="${TEAM:-}"; PASS="${PASS:-bb123#123}"     # default packet password until you rotate
save_env(){ umask 077; printf 'TEAM=%s\nPASS=%q\n' "$TEAM" "$PASS" > "$ENVF"; }

C_R=$'\e[31m'; C_G=$'\e[32m'; C_Y=$'\e[33m'; C_B=$'\e[36m'; C_N=$'\e[0m'
log(){ printf '%s[deploy]%s %s\n' "$C_B" "$C_N" "$*"; }
ok(){  printf '%s[ ok ]%s %s\n' "$C_G" "$C_N" "$*"; }
warn(){ printf '%s[warn]%s %s\n' "$C_R" "$C_N" "$*"; }

for c in sshpass ssh scp nc ping; do command -v "$c" >/dev/null || { warn "missing '$c' (apt install $c)"; MISSING=1; }; done
[[ "${MISSING:-0}" == 1 ]] && { warn "install the missing tools and re-run"; exit 1; }

# ---- hardcoded FA26 inventory ----
ROLES=(router web file msgboard dc)
declare -A SUFFIX=([router]=1 [web]=10 [file]=20 [msgboard]=30 [dc]=40)
declare -A OS=([router]=pfsense [web]=ubuntu [file]=ubuntu [msgboard]=canaima [dc]=windows)
declare -A LUSER=([router]=admin [web]=root [file]=root [msgboard]=root [dc]=Administrator)
declare -A SCORED=([router]="ICMP DNS" [web]="ICMP SSH HTTP" [file]="ICMP SSH FTP SMB" [msgboard]="ICMP SSH MsgBoard" [dc]="ICMP SSH DNS CA")
declare -A HROLE=([web]=web [file]=file [msgboard]=msgboard)    # -> harden.sh role name
# TCP ports to probe for `status` (DNS handled separately; CA approximated by RPC/135)
declare -A PROBE=([router]="" [web]="22 80" [file]="22 21 445" [msgboard]="22 80" [dc]="22 53 135 3389")

ip_of(){ echo "172.16.${TEAM}.${SUFFIX[$1]}"; }
SSH_OPTS=(-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=8 -o LogLevel=ERROR)
sshrun(){ local r=$1 cmd=$2; sshpass -p "$PASS" ssh "${SSH_OPTS[@]}" "${LUSER[$r]}@$(ip_of "$r")" "$cmd"; }
sshint(){ local r=$1 cmd=$2; sshpass -p "$PASS" ssh "${SSH_OPTS[@]}" -t "${LUSER[$r]}@$(ip_of "$r")" "$cmd"; }
scpto(){  local r=$1 src=$2 dst=$3; sshpass -p "$PASS" scp "${SSH_OPTS[@]}" -r "$src" "${LUSER[$r]}@$(ip_of "$r"):$dst"; }
scpfrom(){ local r=$1 src=$2 dst=$3; sshpass -p "$PASS" scp "${SSH_OPTS[@]}" "${LUSER[$r]}@$(ip_of "$r"):$src" "$dst"; }

need_team(){
  if [[ -z "$TEAM" ]]; then read -r -p "Team number (the X in 172.16.X.0/24): " TEAM; fi
  [[ "$TEAM" =~ ^[0-9]+$ ]] || { warn "team number must be numeric"; exit 1; }
  save_env
}

# only these roles, or all
pick_roles(){ if [[ $# -gt 0 ]]; then for r in "$@"; do [[ -n "${SUFFIX[$r]:-}" ]] || { warn "unknown role: $r"; exit 1; }; echo "$r"; done; else printf '%s\n' "${ROLES[@]}"; fi; }

# ============================================================ commands
cmd_inventory(){ need_team
  printf '\n  %-9s %-16s %-10s %-13s %s\n' ROLE IP OS LOGIN SCORED
  for r in "${ROLES[@]}"; do printf '  %-9s %-16s %-10s %-13s %s\n' "$r" "$(ip_of "$r")" "${OS[$r]}" "${LUSER[$r]}" "${SCORED[$r]}"; done
  echo; log "scoreboard: $SCOREBOARD   (checks every 60s)"
}

cmd_status(){ need_team
  log "probing scored services (not the official board - a jumpbox sanity check)"
  for r in "${ROLES[@]}"; do
    local ip; ip=$(ip_of "$r")
    if ping -c1 -W2 "$ip" >/dev/null 2>&1; then icmp="${C_G}ICMP${C_N}"; else icmp="${C_R}ICMP${C_N}"; fi
    local line="  ${r} (${ip}): $icmp"
    for p in ${PROBE[$r]}; do
      if nc -z -w2 "$ip" "$p" >/dev/null 2>&1; then line+=" ${C_G}${p}${C_N}"; else line+=" ${C_R}${p}${C_N}"; fi
    done
    # DNS boxes: actually resolve something
    if [[ "${SCORED[$r]}" == *DNS* ]]; then
      if command -v dig >/dev/null && dig +time=2 +tries=1 @"$ip" rumscoring.uacyber.org >/dev/null 2>&1; then line+=" ${C_G}DNS${C_N}"; else line+=" ${C_R}DNS${C_N}"; fi
    fi
    echo -e "$line"
  done
  echo; log "red = unreachable from the jumpbox. Confirm against the real board: $SCOREBOARD"
}

cmd_push(){ for r in $(pick_roles "$@"); do
    log "push -> $r ($(ip_of "$r"))"
    case "${OS[$r]}" in
      ubuntu|canaima) scpto "$r" "$KIT/linux" "/root/" && ok "$r: /root/linux" || warn "$r push failed" ;;
      windows)        sshrun "$r" 'cmd /c "if not exist C:\kit mkdir C:\kit"' 2>/dev/null; scpto "$r" "$KIT/windows" "C:/kit/" && ok "$r: C:\\kit\\windows" || warn "$r push failed (OpenSSH on the DC up?)" ;;
      pfsense)        scpto "$r" "$KIT/pfsense/pf-audit.sh" "/tmp/" && ok "$r: /tmp/pf-audit.sh" || warn "$r: scp failed - pfSense harden is GUI-manual anyway (see harden)" ;;
    esac
  done; }

cmd_triage(){ mkdir -p reports; for r in $(pick_roles "$@"); do
    log "triage (read-only) -> $r"
    case "${OS[$r]}" in
      ubuntu|canaima) sshrun "$r" "cd /root/linux && bash hunt.sh --quick 2>&1; echo '=== AGENT HUNT ==='; bash agent-hunt.sh --audit 2>&1" > "reports/$r-hunt.txt" 2>&1 && ok "reports/$r-hunt.txt ($(grep -c '\[!\]' "reports/$r-hunt.txt" 2>/dev/null) flags)" || warn "$r triage failed" ;;
      windows)        sshrun "$r" 'powershell -ExecutionPolicy Bypass -File C:/kit/windows/Hunt.ps1' > "reports/$r-hunt.txt" 2>&1 && ok "reports/$r-hunt.txt" || warn "$r triage failed" ;;
      pfsense)        sshrun "$r" 'sh /tmp/pf-audit.sh' > "reports/$r-audit.txt" 2>&1 && ok "reports/$r-audit.txt" || warn "$r: couldn't run audit over SSH - open the pfSense GUI and use pfsense/pf-audit.sh from the console" ;;
    esac
  done
  echo; log "read them:  less reports/*-hunt.txt   (grep -n '\\[!\\]' reports/*.txt for the flags)"; }

cmd_rotate(){ need_team
  warn "This changes root/Administrator on every box from the default. Scored USERS are left alone."
  # NEWPASS env lets the web app drive this non-interactively; otherwise prompt.
  local NEW="${NEWPASS:-}"
  [[ -z "$NEW" ]] && read -r -p "New team password (no quotes): " NEW
  [[ "$NEW" == *\'* || "$NEW" == *\"* ]] && { warn "no quotes in the password"; exit 1; }
  [[ -z "$NEW" ]] && { warn "empty"; exit 1; }
  for r in $(pick_roles "$@"); do
    case "${OS[$r]}" in
      ubuntu|canaima) sshrun "$r" "echo 'root:${NEW}' | chpasswd" && ok "$r: root rotated" || warn "$r rotate failed" ;;
      windows)        sshrun "$r" "net user Administrator ${NEW}" >/dev/null && ok "$r: Administrator rotated" || warn "$r rotate failed" ;;
      pfsense)        warn "$r: change the pfSense admin password in the GUI (System > User Manager) - can't script FreeBSD GUI auth safely" ;;
    esac
  done
  PASS="$NEW"; save_env
  ok "connection password updated to the new one (saved in $ENVF). Later phases use it automatically."
}

cmd_harden(){ need_team
  local list; mapfile -t list < <(pick_roles "$@")
  log "STAGGERED harden - one box at a time. Watch $SCOREBOARD after each before continuing."
  for r in "${list[@]}"; do
    echo; log "===== next: $r ($(ip_of "$r")) - scored: ${SCORED[$r]} ====="
    read -r -p "Harden $r now? [y]es / [s]kip / [q]uit: " a
    case "$a" in
      [Ss]*) warn "skipped $r"; continue ;;
      [Qq]*) warn "stopped."; break ;;
    esac
    case "${OS[$r]}" in
      ubuntu|canaima) sshint "$r" "cd /root/linux && ./harden.sh ${HROLE[$r]}" ;;
      windows)        sshint "$r" 'powershell -ExecutionPolicy Bypass -File C:/kit/windows/Harden.ps1 -Role DC' ;;
      pfsense)        print_pf_harden ;;
    esac
    echo; warn "CHECK THE SCOREBOARD for $r's services (${SCORED[$r]}) before moving on."
    read -r -p "Press Enter when $r is green on the board..." _
  done
  ok "staggered harden complete. Leave './deploy.sh sweep 5' running to catch re-compromise."
}

print_pf_harden(){ cat <<EOF
${C_Y}pfSense ($(ip_of router)) is hardened in the GUI, not by a pushed script:${C_N}
  https://$(ip_of router)  (admin / your rotated password)
  1. System > User Manager: change admin password (if not done), remove unknown users.
  2. Firewall > Rules > WAN: there should be NO allow rules you didn't make. Remove red-team adds.
  3. Firewall > NAT > Port Forward: delete any forward you didn't create (a door to an inside box).
  4. Services > DNS Resolver (Unbound): ENABLED - DNS is scored. Diagnostics > check it resolves.
  5. Diagnostics > Command Prompt: run the audit you pushed:  sh /tmp/pf-audit.sh
  6. Keep ICMP (ping) allowed on the interfaces - it's scored.
EOF
read -r -p "Press Enter when you've worked the pfSense checklist..." _
}

cmd_sweep(){ need_team; local mins="${1:-5}"; mkdir -p reports/sweep
  log "sweep every ${mins}m. Baseline first, then alert on changes. Ctrl-C to stop."
  for r in web file msgboard dc; do cmd_triage "$r" >/dev/null 2>&1; cp -f "reports/$r-hunt.txt" "reports/sweep/$r.base" 2>/dev/null; done
  ok "baseline taken"
  while true; do
    sleep $(( mins * 60 ))
    for r in web file msgboard dc; do
      cmd_triage "$r" >/dev/null 2>&1 || continue
      if ! diff -q "reports/sweep/$r.base" "reports/$r-hunt.txt" >/dev/null 2>&1; then
        warn "$(date +%T) CHANGE on $r:"; diff "reports/sweep/$r.base" "reports/$r-hunt.txt" | grep -E '^[<>]' | head -20
        cp -f "reports/$r-hunt.txt" "reports/sweep/$r.base"
      fi
    done
  done
}

usage(){ sed -n '2,30p' "$0" | sed 's/^# \{0,1\}//'; }

case "${1:-}" in
  inventory) cmd_inventory ;;
  status)    cmd_status ;;
  push)      shift; cmd_push "$@" ;;
  triage)    shift; cmd_triage "$@" ;;
  rotate)    shift; cmd_rotate "$@" ;;
  harden)    shift; cmd_harden "$@" ;;
  sweep)     shift; cmd_sweep "$@" ;;
  *)         usage ;;
esac
