# Jumpbox orchestrator — drive the whole kit from one Kali box

Two front-ends, same engine. `deploy.sh` is the CLI; `jumpbox-web.py` is a local web dashboard on
top of it (nicer for the whole team to watch). Both are **hardcoded to the FA26 topology** — the only
input is your team number, from which every IP is derived (`172.16.X.{1,10,20,30,40}`).

## Web dashboard (recommended for the team)

```bash
sudo apt install -y ttyd          # one-time: the in-browser terminal for the Harden buttons
./deploy.sh inventory             # set your team number once (saved to .jump.env)
python3 jumpbox-web.py            # open http://127.0.0.1:8000 ON THE JUMPBOX
```
- **Live status board** — red/green grid of every scored service, refreshing every 10s.
- **Safe one-click actions** — Push, Triage (reports shown inline), Rotate (password field), Start sweep.
- **Per-box Harden button** — opens the REAL interactive harden session in an embedded terminal, so
  you still approve every step. One box per button = staggered; watch the board before the next box.
- Binds **127.0.0.1 only**. To view from another of your machines: `ssh -L 8000:127.0.0.1:8000 kali@<jumpbox>`.
  Never expose it — it can SSH-as-root to every box.

## CLI (same actions, scriptable)

`deploy.sh` pushes the kit to every scored box over SSH, then runs triage / rotation / hardening /
a re-compromise sweep across all of them from one place.

SSH is on every box this year (all three Linux servers, pfSense, and the DC — SSH is scored on it),
so one transport reaches everything.

## Order of operations (game day)

```bash
# On the Kali jumpbox, with the kit cloned (this is lab/jumpbox/):
./deploy.sh inventory          # confirm the IPs for your team number
./deploy.sh status             # quick up/down of every scored service
./deploy.sh push               # copy the kit to every box
./deploy.sh triage             # read-only hunt + agent-audit on all boxes -> reports/ (SAFE)
#   -> read reports/*-hunt.txt, grep for [!]
./deploy.sh rotate             # change root/Administrator off the default (SAFE, big win)
./deploy.sh harden             # STAGGERED: one box at a time, pauses for you to watch the board
./deploy.sh sweep 5            # leave running: re-triage every 5 min, alerts on re-compromise
```

You can scope any phase to specific boxes: `./deploy.sh harden web file`, `./deploy.sh triage dc`.

## What's automated vs. you-in-the-loop (by design)

- **Fully automated (safe):** `push`, `triage`, `rotate`, `sweep`. These are read-only or low-risk and
  benefit from doing all five boxes at once.
- **Staggered, you-in-the-loop:** `harden`. It does ONE box, then stops and makes you confirm the
  scoreboard is green before the next. This is deliberate — hardening all five unattended is the
  fastest way to red-line the whole board. The per-box `harden.sh`/`Harden.ps1` still prompt per step.
- **pfSense is GUI-manual.** You can't safely script FreeBSD's GUI auth, so for the router the
  orchestrator pushes + runs the read-only audit and prints the exact GUI checklist.

## Notes

- Creds live in `.jump.env` (chmod 600): your team number and the current working password. `rotate`
  updates the password there so later phases keep working. Delete the file after the competition.
- It uses `sshpass` (preinstalled on Kali). First connection to each host auto-accepts the host key.
- `rotate` changes **root/Administrator only**, never the scored users — the scoring engine may
  authenticate as them, and changing those blind can fail checks. Ask White Team before touching them.
- The Windows DC is driven as `powershell -ExecutionPolicy Bypass -File C:\kit\windows\...` over SSH,
  so OpenSSH Server must be up on it. `Harden.ps1 -Role DC` installs/enables it (step 6b) — but it's
  also what the scoreboard checks, so if the DC shows no SSH early, fix that first (console in via
  Proxmox, `Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0; Start-Service sshd`).
- This is a plain orchestration script (ssh/scp in a loop). It is **not** an autonomous agent and
  doesn't call any AI, so it's clear of the packet's rule-10 ban.
